"""DJI WPML/KMZ export service API."""

def build_dji_kmz(*args, **kwargs):
    """Write a DJI WPML/KMZ mission through the compatibility bridge."""
    try:
        from acmp._legacy import build_dji_kmz as implementation
    except ImportError as error:
        raise RuntimeError(
            "Der DJI-Export benötigt derzeit Python 3.12. "
            "Starte ACMP mit: py -3.12 main.py"
        ) from error
    return implementation(*args, **kwargs)

__all__ = ["build_dji_kmz"]
